# portfolio-os
My portfolio website

### Run this command for tailwindcss
npx tailwindcss -i ./src/input.css -o ./dist/output.css --watch
